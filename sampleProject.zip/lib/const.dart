
import 'package:flutter/material.dart';

ThemeData lightTheme = ThemeData(
  brightness: Brightness.light,
  primaryColor: Colors.white,
  fontFamily: "RobotoSlab",
  scaffoldBackgroundColor: const Color(0xFFF4F6FF),
  appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF4F6FF)),
);