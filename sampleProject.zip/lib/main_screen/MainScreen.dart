import 'package:flutter/material.dart';
import 'package:hantaton2025/main_screen/Operations.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {

  final MainScreenOperations _mainScreenOperations = MainScreenOperations();

  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
