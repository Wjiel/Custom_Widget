import 'package:flutter/material.dart';
import 'package:hantaton2025/start_screen/Operations.dart';

class StartScreen extends StatefulWidget {
  const StartScreen({super.key});

  @override
  State<StartScreen> createState() => _StartScreenState();
}

class _StartScreenState extends State<StartScreen> {

  final StartScreenOperations _startScreenOperations = StartScreenOperations();

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
