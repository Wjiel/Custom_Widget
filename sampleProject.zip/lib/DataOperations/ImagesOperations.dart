import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';

class ImagesOperations {

  Future precacheAssets(context) async {

    List _allImages = [ ];
    List _allIcons = [ ];

    final imagesManifest = await AssetManifest.loadFromAssetBundle(rootBundle);
    _allImages = imagesManifest.listAssets().where((string) => string.startsWith("assets/images/")).toList();
    final iconsManifest = await AssetManifest.loadFromAssetBundle(rootBundle);
    _allIcons = iconsManifest.listAssets().where((string) => string.startsWith("assets/icons/")).toList();

    for(var asset in _allImages)
    {
      await precacheImage(AssetImage(asset), context);
    }

    for(var asset in _allIcons)
    {
      await precacheSvgPicture(asset);
    }
  }

  Future precacheSvgPicture(String svgPath) async {
    final logo = SvgAssetLoader(svgPath);
    await svg.cache.putIfAbsent(logo.cacheKey(null), () => logo.loadBytes(null));
  }

}