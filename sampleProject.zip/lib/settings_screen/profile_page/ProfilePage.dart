import 'package:flutter/material.dart';
import 'package:hantaton2025/settings_screen/profile_page/Operations.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {

  final ProfilePageOperations _profilePageOperations = ProfilePageOperations();

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
