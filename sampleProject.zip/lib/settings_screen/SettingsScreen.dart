import 'package:flutter/material.dart';
import 'package:hantaton2025/settings_screen/Operations.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {

  final SettingsScreenOperations _settingsScreenOperations = SettingsScreenOperations();

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
