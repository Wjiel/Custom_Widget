import 'dart:async';
import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:hantaton2025/DataOperations/ImagesOperations.dart';
import 'DataOperations/Shared_Prefences.dart';
import 'const.dart';
import 'firebase_options.dart';
import 'login_screen/LoginScreen.dart';
import 'main_screen/MainScreen.dart';



void main() async{

  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );



  //unawaited(RiveFile.initialize());
  runApp(
      MaterialApp(
          theme: lightTheme,
          home: const MyApp()
      )
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const SplashScreen();
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {



  Future _checkLaunch() async {

    await ImagesOperations().precacheAssets(context);

    try {
      bool _isFirstStart = await getBool("isFirstStart") ?? true;

      if (_isFirstStart == false) {
        _navigateToLogin();
      } else {
        _navigateToMain();
      }
    } catch (e) {
      _navigateToLogin();
    }


  }



  @override
  void initState() {
    super.initState();
    _checkLaunch();
  }

  void _navigateToLogin() {
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => LoginScreen()));
  }

  void _navigateToMain() async {
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=> MainScreen()));
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Container(
        margin: EdgeInsets.all(80),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          image: DecorationImage(image: AssetImage("assets/images/logoinversenoicon.png")),
          borderRadius: BorderRadius.circular(15),
        ),
      ),
    );
  }
}


class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}