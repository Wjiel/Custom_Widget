import 'package:flutter/material.dart';
import 'package:hantaton2025/login_screen/Operations.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  final LoginScreenOperations _loginOperations = LoginScreenOperations();

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
